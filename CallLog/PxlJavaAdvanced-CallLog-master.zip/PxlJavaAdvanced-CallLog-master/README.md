# Algemene oefening Java Advanced

Opgave oefening en test data op [blackboard](https://bb.pxl.be/webapps/blackboard/content/listContentEditable.jsp?content_id=_1086581_1&course_id=_26655_1)



